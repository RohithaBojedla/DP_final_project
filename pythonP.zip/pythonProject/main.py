"""
import pandas as pd
from flask import Flask, render_template, jsonify
from pymongo import MongoClient

app = Flask(__name__)

# Load dataset
dataset_url = 'https://raw.githubusercontent.com/SaiManoj0511/Testing-/main/spotify_songs.csv'
df = pd.read_csv(dataset_url)

# Convert DataFrame to list of dictionaries
data = df.to_dict(orient='records')


# Connect to MongoDB
client = MongoClient('mongodb+srv://saimanoj:400FZAnYTHoZa6Fe@saimanojm.adg7nkd.mongodb.net/?retryWrites=true&w=majority')
db = client['spotify_data']
collection = db['songs']

# Insert data into MongoDB collection

collection.insert_many(data)
#print(data)


# Define a route to render the index.html template
@app.route('/')
def display_data():
    client = MongoClient('mongodb+srv://saimanoj:400FZAnYTHoZa6Fe@saimanojm.adg7nkd.mongodb.net/?retryWrites=true&w=majority')
    db = client["spotify_data"]
    collection = db["songs"]
    # Retrieve data from MongoDB
    data = list(collection.find({}, {'_id': 0}).limit(1000))

  # Render an HTML template and pass the data to it
    return render_template('index.html', data=data)



# Add a new route to serve data
@app.route('/api/data', methods=['GET'])
def api_data():
    # You may want to replace this with the actual data retrieval logic
    # For now, I'm returning the first 5 records from the MongoDB collection
    client = MongoClient('mongodb+srv://saimanoj:400FZAnYTHoZa6Fe@saimanojm.adg7nkd.mongodb.net/?retryWrites=true&w=majority')
    db = client["spotify_data"]
    collection = db["songs"]
    data = list(collection.find({}, {'_id': 0}).limit(1000))
    #print(data)
    # Return data as JSON
    return jsonify(data)



if __name__ == '__main__':

    app.run(debug=True, port=4000)

    """

import pandas as pd
from flask import Flask, render_template, jsonify
from pymongo import MongoClient
import schedule
import time

app = Flask(__name__)

# Load dataset
dataset_url = 'https://raw.githubusercontent.com/SaiManoj0511/Testing-/main/spotify_songs.csv'
df = pd.read_csv(dataset_url)

# Convert DataFrame to list of dictionaries
data = df.to_dict(orient='records')

# Connect to MongoDB
client = MongoClient('mongodb+srv://saimanoj:400FZAnYTHoZa6Fe@saimanojm.adg7nkd.mongodb.net/?retryWrites=true&w=majority')
db = client['spotify_data']
collection = db['songs']

# Insert data into MongoDB collection
collection.insert_many(data)


# print(data)

# Function to insert data into MongoDB
def insert_data_into_mongodb():
    # Load dataset
    df = pd.read_csv(dataset_url)
    data = df.to_dict(orient='records')

    # Insert data into MongoDB collection
    collection.insert_many(data)


# Schedule the job to run every 24 hours
schedule.every(30).seconds.do(insert_data_into_mongodb)


# Define a route to render the index.html template
@app.route('/')
def display_data():
    # Retrieve data from MongoDB
    data = list(collection.find({}, {'_id': 0}).limit(1000))

    # Render an HTML template and pass the data to it
    return render_template('index.html', data=data)


# Add a new route to serve data
@app.route('/api/data', methods=['GET'])
def api_data():
    # Retrieve data from MongoDB
    data = list(collection.find({}, {'_id': 0}).limit(1000))

    # Return data as JSON
    return jsonify(data)


if __name__ == '__main__':
    # Run the Flask app in debug mode
    app.run(debug=True, port=4000)

    # Run the scheduler in a separate thread
    while True:
        schedule.run_pending()
        time.sleep(1)